export interface Sidebar {
link: string;
r_TipoServicio: string;
r_NombreServicio: string;
R_NOM_TABLA: string;
R_Id: string;
R_Nombre: string;
R_Descripcion: string;
R_Proce_pro_rsta: string;
R_Sistema_fuente: string;
R_Tipo: string;
R_Url: string;
R_Metodo: string;
R_Content_Type: string;
R_Accept: string;
R_Credenciales: string;

}
